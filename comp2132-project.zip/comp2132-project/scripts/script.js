"use strict";

const gameState = {
    words: [],
    selectedWord: "",
    hint: "",
    guessedLetters: [],
    wrongGuesses: 0,
    maxWrongGuesses: 6,
    gameOver: false
};

const wordDisplay = document.getElementById("wordDisplay");
const hintDisplay = document.getElementById("hint");
const keyboard = document.getElementById("keyboard");
const livesDisplay = document.getElementById("lives");
const wrongLettersDisplay = document.getElementById("wrongLetters");
const cookie = document.getElementById("cookie");
const cookieMessage = document.getElementById("cookieMessage");
const progressBar = document.getElementById("progressBar");
const resultSection = document.getElementById("resultSection");
const resultTitle = document.getElementById("resultTitle");
const resultMessage = document.getElementById("resultMessage");
const playAgainButton = document.getElementById("playAgain");
const santa = document.getElementById("santa");
const snowContainer = document.getElementById("snowContainer");

async function loadWords() {
    try {
        const response = await fetch("./data/words.json");

        if(!response.ok) {
            throw new Error("Unable to load the word database.");
        }

        const data = await response.json();
        gameState.words = data.words;

        startGame();

    } catch (error) {
        wordDisplay.textContent = "Unable to load game!";
        hintDisplay.textContent =
            "Please run the project using a local web server.";
            console.error(error);
    }
}

function selectRandomWord(){

    if(!Array.isArray(gameState.words) || gameState.words.length === 0) {
        console.error("No words found in the database!");
        return;
    }

    const randomIndex = Math.floor(
        Math.random() * gameState.words.length
    );

    const selected = gameState.words[randomIndex];

    gameState.selectedWord = selected.word.toLowerCase();
    gameState.hint = selected.hint;
}

function startGame() {
    gameState.guessedLetters = [];
    gameState.wrongGuesses = 0;
    gameState.gameOver = false;

    selectRandomWord();

    hintDisplay.textContent = gameState.hint;
    livesDisplay.textContent = gameState.maxWrongGuesses;
    wrongLettersDisplay.textContent = "None";

    cookie.src = "images/cookie-full.png";
    cookie.className = "cookie";

    cookieMessage.textContent =
        "Keep Santa away from your cookie!";

        progressBar.style.width = "100%";

        santa.classList.remove("eat-animation");

        resultSection.style.display = "none";
        keyboard.style.display = "grid";

        createKeyboard();
        updateWordDisplay();
}

function createKeyboard() {
    keyboard.innerHTML = "";

    const alphabet = "abcdefghijklmnopqrstuvwxyz";

    for(const letter of alphabet) {
        const button = document.createElement("button");

        button.textContent = letter.toUpperCase();
        button.classList.add("letter-button");
        button.type = "button";
        button.dataset.letter = letter;

        button.addEventListener("click", function () {
               makeGuess(letter);
        });

        keyboard.appendChild(button);
    }
}

function updateWordDisplay() {
    const displayedWord = gameState.selectedWord
                                   .split("")
                                   .map(letter => {
                                        return gameState.guessedLetters.includes(letter)
                                        ? letter.toUpperCase() : "_";
                                   });

    wordDisplay.textContent = displayedWord.join(" ");

    checkWin();
}

function makeGuess(letter) {
    if(gameState.gameOver) {
        return;
    }

    if(gameState.guessedLetters.includes(letter)) {
        return;
    }

    gameState.guessedLetters.push(letter);

    const button = keyboard.querySelector(
        `[data-letter="${letter}"]`
    );

    if(button) {
        button.disabled = true;
    }

    if(gameState.selectedWord.includes(letter)) {
        updateWordDisplay();

        if(!gameState.gameOver) {
            wordDisplay.classList.remove("word-animation");
            void wordDisplay.offsetWidth;
            wordDisplay.classList.add("word-animation");
        }

    } else {
        gameState.wrongGuesses++;

        updateWrongGuessDisplay();
        updateCookie();

        if(gameState.wrongGuesses >= gameState.maxWrongGuesses) {
            endGame(false);
        }
    }
}

function updateWrongGuessDisplay() {
    const wrongLetters = gameState.guessedLetters.filter(letter =>
        {
            return !gameState.selectedWord.includes(letter);
        });

        wrongLettersDisplay.textContent =
            wrongLetters.map(letter => letter.toUpperCase()).join(",") || "None";

            livesDisplay.textContent =
                gameState.maxWrongGuesses - gameState.wrongGuesses;
}

function updateCookie()
{
    const cookieImages = [
        "images/cookie-full,png",
        "images/cookie-bite-1.png",
        "images/cookie-bite-2.png",
        "images/cookie-bite-3.png",
        "images/cookie-bite-4.png",
        "images/cookie-bite-5.png",
        "images/cookie-gone.png"
    ];

    const biteMessage = [
        "Santa is getting hungry...",
        "Santa takes a little bite!",
        "Oh no! Santa wants more!",
        "Santa is enjoying that cookie!",
        "The cookie is almost gone!",
        "Only crumbs are left!",
        "Santa ate the whole cookie!"
    ];

    cookie.src = cookieImages[gameState.wrongGuesses];

    cookieMessage.textContent = 
        biteMessage[gameState.wrongGuesses];

    const remainingPercentage =
        ((gameState.maxWrongGuesses - gameState.wrongGuesses) /
        gameState.maxWrongGuesses) * 100;

    progressBar.style.width = remainingPercentage + "%";

    santa.classList.remove("eat-animation");
    void santa.offsetWidth;
    santa.classList.add("eat-animation");
}

function checkWin() {
    const wordGuessed = gameState.selectedWord
                                 .split("")
                                 .every(letter => {
                                    return gameState.guessedLetters.includes(letter);
                                 });

    if(wordGuessed) {
        endGame(true);
    }
}

function endGame(won) {
    gameState.gameOver = true;

    const buttons = keyboard.querySelectorAll("button");

    buttons.forEach(button => {
        button.disabled = true;
    });

    keyboard.style.display = "none";
    resultSection.style.display = "block";

    if(won) {
        resultTitle.textContent = "YOU WIN!";

        resultMessage.textContent =
            "You saved the cookie! Santa will have to find another snack." +
            "The word was " + gameState.selectedWord.toUpperCase() + "!";

            cookieMessage.textContent = "The cookie is SAFE!";
            cookie.className = "cookie cookie-saved";

    } else {
        resultTitle.textContent = "SANTA WINS!";

        resultMessage.textContent =
            "Oh no! Santa ate the entire cookie! " +
            "The correct word was " +
            gameState.selectedWord.toUpperCase() + ".";

        cookie.src = "images/cookie-gone.png";
        cookie.className = "cookie cookie-gone";
    }
}

playAgainButton.addEventListener("click", function() {
    startGame();
});

function createSnow() {
    const snowflake = document.createElement("span");

    snowflake.classList.add("snowflake");
    snowflake.textContent = "❄️";

    snowflake.style.left = Math.random() * 100 + "%";

    snowflake.style.animationDuration =
        (Math.random() * 5 + 5) +"s";

        snowflake.style.opacity = Math.random();

        snowflake.style.fontSize =
            (Math.random() * 12 + 10) + "px";

            snowContainer.appendChild(snowflake);

            snowflake.addEventListener("animationend", function() {
                snowflake.remove();
            });
}

setInterval(createSnow, 300);

loadWords();